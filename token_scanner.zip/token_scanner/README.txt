TOKEN SCANNER - TERMUX

1. Dézipper : unzip token_scanner.zip && cd token_scanner
2. Installer : bash setup.sh
3. Configurer : nano .env  (TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, idéalement SOLANA_RPC_URL Helius/QuickNode)
4. Lancer : bash run.sh

Pour qu'il tourne en arrière-plan sans garder l'écran ouvert :
  pkg install tmux
  tmux new -s bot
  bash run.sh
  (détacher : Ctrl+B puis D ; revenir : tmux attach -t bot)

Android : désactive l'optimisation de batterie pour Termux
(Paramètres > Applis > Termux > Batterie > Sans restriction),
sinon le système peut tuer le bot.
