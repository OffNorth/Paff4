"""Bot Telegram : détecte les tokens Pump.fun qui passent MIN_MC_USD de market cap,
les scanne (authorities, holders, liquidité, RugCheck, Twitter) et n'envoie
que ceux dont le score >= MIN_SCORE.
Verdict = "aucun red flag détecté", jamais "safe"."""
import asyncio, html, json, logging, os, re
from datetime import datetime, timezone

import httpx
import websockets
from dotenv import load_dotenv

load_dotenv()
TG_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
TG_CHAT = os.environ["TELEGRAM_CHAT_ID"]
RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
TWITTER_KEY = os.getenv("TWITTERAPI_KEY", "")
MIN_MC = float(os.getenv("MIN_MC_USD", "20000"))
MIN_SCORE = int(os.getenv("MIN_SCORE", "60"))
SEND_ALL = os.getenv("SEND_ALL", "0") == "1"  # 1 = envoie aussi les tokens sous MIN_SCORE
TRACK_MIN = int(os.getenv("TRACK_MINUTES", "60"))  # arrête de suivre un token après X min
WORKERS = 3
WS_URL = "wss://pumpportal.fun/api/data"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("scanner")

tracked: dict[str, dict] = {}  # mint -> infos du token
scanned: set[str] = set()
sol_usd = 150.0
ws_ref = None


# ---------- sources de données ----------
async def get_json(c, url, **kw):
    r = await c.get(url, **kw)
    r.raise_for_status()
    return r.json()


async def rpc_authorities(c, mint):
    r = await c.post(RPC_URL, json={"jsonrpc": "2.0", "id": 1, "method": "getAccountInfo",
                                    "params": [mint, {"encoding": "jsonParsed"}]})
    info = r.json()["result"]["value"]["data"]["parsed"]["info"]
    return info.get("mintAuthority"), info.get("freezeAuthority")


async def dexscreener(c, mint):
    pairs = (await get_json(c, f"https://api.dexscreener.com/latest/dex/tokens/{mint}")).get("pairs") or []
    return max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd", 0)) if pairs else None


async def rugcheck(c, mint):
    return await get_json(c, f"https://api.rugcheck.xyz/v1/tokens/{mint}/report")


async def metadata(c, uri):
    return await get_json(c, uri) if uri else {}


async def twitter_info(c, user):
    d = (await get_json(c, "https://api.twitterapi.io/twitter/user/info",
                        params={"userName": user}, headers={"X-API-Key": TWITTER_KEY})).get("data") or {}
    age = None
    try:
        created = datetime.strptime(d["createdAt"], "%a %b %d %H:%M:%S %z %Y")
        age = (datetime.now(timezone.utc) - created).days
    except Exception:
        pass
    return {"followers": d.get("followers"), "age_days": age}


def twitter_username(url):
    m = re.search(r"(?:twitter|x)\.com/([A-Za-z0-9_]{1,15})(?:[/?#]|$)", url or "")
    return m.group(1) if m and m.group(1).lower() not in {"i", "home", "search", "intent"} else None


# ---------- scan + score ----------
async def scan(c, mint):
    tok = tracked.get(mint, {})
    auth, dex, rug, meta = await asyncio.gather(
        rpc_authorities(c, mint), dexscreener(c, mint), rugcheck(c, mint),
        metadata(c, tok.get("uri")), return_exceptions=True)
    score, reasons = 100, []

    def add(delta, text):
        nonlocal score
        score += delta
        reasons.append(("✅ " if delta == 0 else "⚠️ ") + text)

    # authorities
    if isinstance(auth, Exception):
        add(-10, "authorities non vérifiables (RPC)")
    else:
        add(-40 if auth[0] else 0, "mint authority NON révoquée" if auth[0] else "mint authority révoquée")
        add(-30 if auth[1] else 0, "freeze authority NON révoquée" if auth[1] else "freeze authority révoquée")

    # RugCheck : holders + risques
    if isinstance(rug, Exception):
        add(-5, "RugCheck indisponible")
    else:
        if rug.get("rugged"):
            add(-100, "RugCheck : token rug")
        danger = [r.get("name") for r in rug.get("risks") or [] if r.get("level") == "danger"]
        if danger:
            add(-min(15 * len(danger), 40), "RugCheck danger : " + ", ".join(danger[:3]))
        holders = sorted(rug.get("topHolders") or [], key=lambda h: -(h.get("pct") or 0))
        if holders and (holders[0].get("pct") or 0) > 30:
            holders = holders[1:]  # exclut la bonding curve / LP
        top10 = sum(h.get("pct") or 0 for h in holders[:10])
        add(-20 if top10 > 35 else -10 if top10 > 25 else 0, f"top 10 holders : {top10:.0f}%")
        dev = next((h.get("pct") or 0 for h in rug.get("topHolders") or []
                    if h.get("address") == tok.get("dev")), 0)
        add(-20 if dev > 10 else -10 if dev > 5 else 0, f"dev détient {dev:.1f}%")

    # liquidité / flux
    liq = h1_buys = h1_sells = None
    if isinstance(dex, dict):
        liq = (dex.get("liquidity") or {}).get("usd")
        tx = (dex.get("txns") or {}).get("h1") or {}
        h1_buys, h1_sells = tx.get("buys", 0), tx.get("sells", 0)
        if liq is not None:
            add(-15 if liq < 5000 else 0, f"liquidité ${liq:,.0f}")
        if h1_buys + h1_sells >= 20:
            add(-10 if h1_buys < 0.8 * h1_sells else 0, f"buys/sells 1h : {h1_buys}/{h1_sells}")
    else:
        add(-5, "pas de données DexScreener")

    # Twitter
    link = ""
    if isinstance(meta, dict):
        link = meta.get("twitter") or ""
    if not link and isinstance(dex, dict):
        link = next((s.get("url", "") for s in (dex.get("info") or {}).get("socials", [])
                     if s.get("type") == "twitter"), "")
    user = twitter_username(link)
    if not user:
        add(-10, "pas de compte Twitter (ou simple communauté)")
    elif not TWITTER_KEY:
        reasons.append("ℹ️ Twitter non analysé (pas de clé API)")
    else:
        try:
            tw = await twitter_info(c, user)
            if tw["age_days"] is not None:
                add(-15 if tw["age_days"] < 7 else 0, f"compte @{user} âgé de {tw['age_days']} j")
            if tw["followers"] is not None:
                add(-10 if tw["followers"] < 100 else 0, f"{tw['followers']} followers")
        except Exception:
            add(-5, "Twitter non vérifiable")

    return {"score": max(score, 0), "reasons": reasons, "user": user}


def format_msg(mint, res):
    tok = tracked.get(mint, {})
    s = res["score"]
    verdict = "🟢 Aucun red flag évident" if s >= 75 else "🟠 Prudence" if s >= MIN_SCORE else "🔴 Danger"
    links = [f'<a href="https://dexscreener.com/solana/{mint}">Dex</a>',
             f'<a href="https://pump.fun/coin/{mint}">Pump</a>',
             f'<a href="https://rugcheck.xyz/tokens/{mint}">RugCheck</a>']
    if res["user"]:
        links.append(f'<a href="https://x.com/{res["user"]}">Twitter</a>')
    return (f"{verdict} — <b>{html.escape(tok.get('name', '?'))}</b> "
            f"(${html.escape(tok.get('symbol', '?'))})\nScore : <b>{s}/100</b> · MC ≥ ${MIN_MC:,.0f}\n\n"
            + "\n".join(res["reasons"])
            + f"\n\n<code>{mint}</code>\n" + " · ".join(links)
            + "\n\n<i>Aucun red flag détecté ≠ sûr. DYOR.</i>")


async def send(c, text):
    await c.post(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                 json={"chat_id": TG_CHAT, "text": text, "parse_mode": "HTML",
                       "disable_web_page_preview": True})


# ---------- boucles ----------
async def worker(queue):
    async with httpx.AsyncClient(timeout=15) as c:
        while True:
            mint = await queue.get()
            try:
                res = await scan(c, mint)
                log.info("scan %s score=%s", mint, res["score"])
                if res["score"] >= MIN_SCORE or SEND_ALL:
                    await send(c, format_msg(mint, res))
            except Exception:
                log.exception("erreur scan %s", mint)


async def refresh_sol_price():
    global sol_usd
    async with httpx.AsyncClient(timeout=10) as c:
        while True:
            try:
                sol_usd = (await get_json(c, "https://api.coingecko.com/api/v3/simple/price",
                                          params={"ids": "solana", "vs_currencies": "usd"}))["solana"]["usd"]
            except Exception:
                log.warning("prix SOL indisponible, on garde %s", sol_usd)
            await asyncio.sleep(120)


async def cleanup():
    while True:
        await asyncio.sleep(60)
        now = asyncio.get_event_loop().time()
        old = [m for m, t in tracked.items() if now - t["ts"] > TRACK_MIN * 60]
        for m in old:
            tracked.pop(m, None)
        if old and ws_ref:
            try:
                await ws_ref.send(json.dumps({"method": "unsubscribeTokenTrade", "keys": old}))
            except Exception:
                pass
        if len(scanned) > 20000:
            scanned.clear()


async def listen(queue):
    global ws_ref
    while True:
        try:
            async with websockets.connect(WS_URL, ping_interval=20) as ws:
                ws_ref = ws
                await ws.send(json.dumps({"method": "subscribeNewToken"}))
                if tracked:
                    await ws.send(json.dumps({"method": "subscribeTokenTrade", "keys": list(tracked)}))
                async for raw in ws:
                    msg = json.loads(raw)
                    mint = msg.get("mint")
                    if not mint:
                        continue
                    if msg.get("txType") == "create":
                        tracked[mint] = {"ts": asyncio.get_event_loop().time(), "dev": msg.get("traderPublicKey"),
                                         "name": msg.get("name"), "symbol": msg.get("symbol"), "uri": msg.get("uri")}
                        await ws.send(json.dumps({"method": "subscribeTokenTrade", "keys": [mint]}))
                    mc_sol = msg.get("marketCapSol")
                    if mint in tracked and mint not in scanned and mc_sol and mc_sol * sol_usd >= MIN_MC:
                        scanned.add(mint)
                        queue.put_nowait(mint)
        except Exception as e:
            log.warning("websocket coupé (%s), reconnexion dans 5s", e)
            await asyncio.sleep(5)


async def main():
    queue: asyncio.Queue = asyncio.Queue()
    await asyncio.gather(listen(queue), refresh_sol_price(), cleanup(),
                         *[worker(queue) for _ in range(WORKERS)])


if __name__ == "__main__":
    asyncio.run(main())
