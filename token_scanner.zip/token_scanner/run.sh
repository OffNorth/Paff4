#!/data/data/com.termux/files/usr/bin/bash
# Lance le bot avec redémarrage automatique. Ctrl+C pour arrêter.
cd "$(dirname "$0")"
termux-wake-lock 2>/dev/null   # empêche Android d'endormir Termux
while true; do
  python bot.py
  echo "Bot arrêté, redémarrage dans 5s (Ctrl+C pour quitter)..."
  sleep 5
done
