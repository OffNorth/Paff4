#!/data/data/com.termux/files/usr/bin/bash
# Installation Termux : bash setup.sh
set -e
pkg update -y
pkg install -y python
pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo ""
echo "Installation terminée. Remplis .env avec : nano .env"
echo "Puis lance : bash run.sh"
